var g_PrevFoundPos = -1;
var g_Highlight = false;
var g_StartPID = "";
var g_SrcPs = new Array();

function Find_Begin()
{
	g_Highlight = false;
}

function Find_End()
{
	g_StartPID = "";
	g_PrevFoundPos = -1;
}

function Find(FindText, CaseSentive)
{
	Find_RemoveAllHighlight(document.body);
	Find_Begin();
	var sId = Find_AndHighlight(document.body, FindText, CaseSentive);
	if( sId == "")
	{
		Find_End();
	}
    else
        window.location = "#" + sId;
    return sId;
}

function Replace(FindText, ReplaceText, CaseSentive)
{
	Find_Begin();
	Replace_Highlight(document.body, ReplaceText);
	var sId = Find_AndHighlight(document.body, FindText, CaseSentive);
	if( sId == "")
	{
		Find_End();
	}
    else
        window.location = "#" + sId;
    return sId;
}

function ReplaceAll(FindText, ReplaceText, CaseSentive)
{
	Find_RemoveAllHighlight(document.body);
	Replace_All(document.body, FindText, ReplaceText, CaseSentive);
}

function GoToHighlightPosition()
{
    if(g_StartPID == "") return;
    window.location = "#" + g_StartPID;
}

function GetJson()
{
    var sRet = Find_GetAllPs_Changed_Json(document.body);
    return sRet;
}

function Save()
{
	
	var sRet = Find_GetAllPs_Changed_Json(document.body);
	console.log(sRet);

}

function Find_RemoveAllHighlight(xBody)
{
	var xNode = xBody.firstChild;
	while(xNode != null)
	{
		if( xNode.nodeType == 1)
		{
			//console.log(xNode.nodeName);
			if( SameText(xNode.nodeName, "span"))
			{
				//console.log(xNode.innerText);
				var xName = xNode.attributes.getNamedItem("name");
				if( xName != null)
					if( SameText(xName.nodeValue, "keyword"))
					{
						xNode.outerHTML = xNode.innerText;
					}
			}
			Find_RemoveAllHighlight(xNode);
		}
		xNode = xNode.nextSibling;
	}
}

function Find_AndHighlight(xBody, FindText, CaseSentive)
{
	//alert(xBody.attributes.getNamedItem("id"));
	//return "";

	var sRet = "";
	var sText, sHtml;
	var xNode = xBody.firstChild;
	while(xNode != null)
	{
		if( xNode.nodeType == 1)
		{ 
			if( ONHTMLNodeType(xNode) == 1)
			{	
				sText = xNode.innerText;
				sHtml = xNode.innerHTML;
				var xId = xNode.attributes.getNamedItem("id");
				if( xId != null )
				{
					var sId = xId.nodeValue;
					if( g_StartPID == sId )
					{	
						//console.log("g:"+g_PrevFoundPos);											
						if( CaseSentive )
							g_PrevFoundPos = FindHTMLStr(sHtml,FindText,g_PrevFoundPos);
						else
							g_PrevFoundPos = FindHTMLText(sHtml,FindText,g_PrevFoundPos);
						//console.log(g_PrevFoundPos+" s:"+sText);
						if( g_PrevFoundPos > -1 )
						{
							var sFoundText = sHtml.substr(g_PrevFoundPos,FindText.length);
							var sFoundTextHtml = '<span name="keyword" style="background:yellow">' + sFoundText + '</span>';
							//console.log(sFoundTextHtml);
							
							var sBefore = xNode.innerHTML.substr(0,g_PrevFoundPos);
							//console.log(sBefore);
							var sAfter = xNode.innerHTML.substr(g_PrevFoundPos + FindText.length);
							//console.log(sAfter);
							sHtml = sBefore + sFoundTextHtml + sAfter;
							//console.log(sHtml);
							xNode.innerHTML = sHtml;

							g_PrevFoundPos += sFoundTextHtml.length;
							
							sRet = sId;
							break;
						}
						else
						{
							g_Highlight = true;
							xNode = xNode.nextSibling;
							continue;
						}
					}

					if( g_StartPID == "" || g_Highlight)
					{
						//console.log("e:"+sText);
						g_PrevFoundPos = -1;
						if( CaseSentive )
							g_PrevFoundPos = FindHTMLStr(sHtml,FindText,g_PrevFoundPos);
						else
							g_PrevFoundPos = FindHTMLText(sHtml,FindText,g_PrevFoundPos);
						if( g_PrevFoundPos > -1 )
						{
							g_StartPID = sId;

							var sFoundText = sHtml.substr(g_PrevFoundPos,FindText.length);
							var sFoundTextHtml = '<span name="keyword" style="background:yellow">' + sFoundText + '</span>';
							//console.log(sFoundTextHtml);
							
							var sBefore = xNode.innerHTML.substr(0,g_PrevFoundPos);
							//console.log(sBefore);
							var sAfter = xNode.innerHTML.substr(g_PrevFoundPos + FindText.length);
							//console.log(sAfter);
							sHtml = sBefore + sFoundTextHtml + sAfter;
							//console.log(sHtml);
							xNode.innerHTML = sHtml;

							g_PrevFoundPos = g_PrevFoundPos + sFoundTextHtml.length;							
							sRet = sId;
							break;
						}
					}
				}
			}
			sRet = Find_AndHighlight(xNode, FindText, CaseSentive);
			if( sRet != "") break;
		}

		xNode = xNode.nextSibling;
	}
	return sRet;	
}

function Replace_Highlight(xBody, ReplaceText)
{
	var iRet = 0;
	var xNode = xBody.firstChild;
	while(xNode != null)
	{
		if( xNode.nodeType == 1)
		{ 
			if( SameText(xNode.nodeName, "span") )
			{	
				
				var xName = xNode.attributes.getNamedItem("name");
				if( xName != null )
				{
					var sName = xName.nodeValue;
					if( sName == "keyword" )
					{	
						xNode.outerHTML = ReplaceText;
						g_PrevFoundPos -= ReplaceText.length;
						iRet = 1;
						break;
					}
					else
						if( Replace_Highlight(xNode, ReplaceText) == 1 ) break;
				}
				else
					if( Replace_Highlight(xNode, ReplaceText) == 1 ) break;
			}
			else
				if( Replace_Highlight(xNode, ReplaceText) == 1 ) break;
		}

		xNode = xNode.nextSibling;
	}
	return iRet;	
}

function Replace_All(xBody, FindText, ReplaceText, CaseSentive)
{
	var iRet = 0;
	var sText, sHtml;
	var iPrevFoundPos, bReplace;
	var xNode = xBody.firstChild;
	while(xNode != null)
	{
		if( xNode.nodeType == 1)
		{ 
			if( ONHTMLNodeType(xNode) == 1 )
			{	
				//console.log(xNode.innerText);
				sText = xNode.innerText;
				sHtml = xNode.innerHTML;
				iPrevFoundPos = -1;
				bReplace = false;
				while( true )
				{
					if( CaseSentive )
						iPrevFoundPos = FindHTMLStr(sHtml,FindText,iPrevFoundPos);
					else
						iPrevFoundPos = FindHTMLText(sHtml,FindText,iPrevFoundPos);
					if( iPrevFoundPos == -1 ) break;						

					var sBefore = sHtml.substr(0,iPrevFoundPos);
					//console.log(sBefore);
					var sAfter = sHtml.substr(iPrevFoundPos + FindText.length);
					//console.log(sAfter);
					sHtml = sBefore + ReplaceText + sAfter;

					iPrevFoundPos = iPrevFoundPos + ReplaceText.length;							
					bReplace = true;													
				}

				if( bReplace )
				{
					xNode.innerHTML = sHtml;
					iRet++;
				}
			}
			
			iRet += Replace_All(xNode, FindText, ReplaceText, CaseSentive);
		}

		xNode = xNode.nextSibling;
	}
	return iRet;	
}

function Find_GetAllPs(xBody)
{
	g_SrcPs.length = 0;
	Find_GetAllPs_Recurse(xBody);
}

function Find_GetAllPs_Recurse(xBody)
{
	var xNode = xBody.firstChild;
	while(xNode != null)
	{
		if( xNode.nodeType == 1)
		{ 
			if( ONHTMLNodeType(xNode) == 1 )
			{	
				//console.log(xNode.innerText);
				var xId  = xNode.attributes.getNamedItem("id");
				if( xId != null )
				{
					var sId = xId.nodeValue;
					var sText = xNode.innerText;
					var sHtml = xNode.outerHTML;
					var aNV = new TANameValue(sId, sText, sHtml);
					g_SrcPs.push(aNV);
				}
			}
			
			Find_GetAllPs_Recurse(xNode);
		}

		xNode = xNode.nextSibling;
	}		
}

function Find_GetAllPs_Changed(xBody, ChangedPs)
{
	ChangedPs.length = 0;
	Find_RemoveAllHighlight(xBody);
	Find_GetAllPs_Changed_Recurse(xBody, ChangedPs);
}

function Find_GetAllPs_Changed_Recurse(xBody, ChangedPs)
{
	var xNode = xBody.firstChild;
	while(xNode != null)
	{
		if( xNode.nodeType == 1)
		{ 
			if( ONHTMLNodeType(xNode) == 1 )
			{	
				//console.log(xNode.innerText);
				var xId  = xNode.attributes.getNamedItem("id");
				if( xId != null )
				{
					var sId = xId.nodeValue;
					var sHtml = xNode.outerHTML;
					var sText = xNode.innerText;
					var aP = FindInArray(g_SrcPs, sId);
					if( aP.Value != sText)
					{
						var aNV = new TANameValue(sId, sText, sHtml);
						ChangedPs.push(aNV);						
					}
				}
			}
			
			Find_GetAllPs_Changed_Recurse(xNode, ChangedPs);
		}

		xNode = xNode.nextSibling;
	}		
}

function Find_GetAllPs_Changed_Json(xBody)
{
	var i, sARplItem;
	var sRet = "";
	var sFormat = "{'target':'%{0}%','action':'replace','content':'%{1}%'}";
	var Ps_Changed = new Array();
	Find_GetAllPs_Changed(xBody, Ps_Changed);
	for(i=0;i<Ps_Changed.length;i++)
	{
		sARplItem = "{'target':'" + Ps_Changed[i].Name + "'," + 
					 "'action':'replace',"+
					 "'content':'" + Ps_Changed[i].Value1 + "'}";
		if(sRet == "") sRet = sARplItem;
		else sRet = sRet + "," + sARplItem;
	}

	if( sRet != "") sRet = "[" + sRet + "]";
	return sRet;
}

function ONHTMLNodeType(HtmlNode)
{
	var iRet = 0;
	var sNodeName = HtmlNode.nodeName.toLowerCase();
	if( sNodeName == 'p') iRet = 1;
	else if( sNodeName == 'li') iRet = 1;
	else if( sNodeName == 'h1') iRet = 1;
	else if( sNodeName == 'h2') iRet = 1;
	else if( sNodeName == 'h3') iRet = 1;
	else if( sNodeName == 'h4') iRet = 1;
	else if( sNodeName == 'h5') iRet = 1;
	else if( sNodeName == 'h6') iRet = 1;

	else if( sNodeName == 'div') iRet = 2;
	else if( sNodeName == 'td') iRet = 2;

	return iRet;
}

function FindHTMLStr(Str, SubStr, PrevFoundPos)
{
	var iRet = -1;
	var iLen = Str.length;
	var i = (PrevFoundPos < 0)?0:PrevFoundPos;
	while(i<iLen)
	{
		if( Str[i] == "<")
		{
			i++;
			while( i<iLen )
			{
				if( Str[i] == ">")
				{
					i++;
					break;
				}
				i++;
			}
			continue;
		}

		if( Str.indexOf(SubStr,i) == i)
		{
			iRet = i;
			break;
		}

		i++;
	}
	return iRet;
}

function FindHTMLText(Str, SubStr, PrevFoundPos)
{
	var iRet = -1;
	var iLen = Str.length;
	var i = (PrevFoundPos < 0)?0:PrevFoundPos;
	var sStr = Str.toLowerCase();
	var sSubStr = SubStr.toLowerCase();
	while(i<iLen)
	{		
		if( Str[i] == "<")
		{
			i++;
			while( i<iLen )
			{
				if( Str[i] == ">")
				{
					i++;
					break;
				}
				i++;
			}
			continue;
		}

		if( sStr.indexOf(sSubStr,i) == i)
		{
			iRet = i;
			break;
		}

		i++;
	}
	return iRet;
}

function SameText(Text1, Text2)
{
	return (Text1.toLowerCase() == Text2.toLowerCase());
}

let TANameValue = class ANameValue 
{
	constructor(Name,Value,Value1)
	{		
		this.Name = Name;
		this.Value = Value;
		this.Value1 = Value1;
	}
};

// let TNameValueList = class NameValueList
// {
// 	m_List = new Array();

// 	Add = function Add(Name, Value)
// 	{
// 		var aNV = new TANameValue(Name,Value);
// 		this.m_List.push(aNV);
// 	};
// };

function FindInArray(ArrayPs, Name)
{
	var i;
	var aRet = null;
	for(i=0;i<ArrayPs.length;i++)
	{
		if( ArrayPs[i].Name == Name )
		{
			aRet = ArrayPs[i];
			break;
		}
	}
	return aRet;
}

Find_GetAllPs(document.body);
